<?php

namespace BS\XFWebSockets\Broadcasting;

class ForumChannel extends Channel
{
    public function join(\XF\Entity\User $visitor): bool
    {
        return true;
    }
}