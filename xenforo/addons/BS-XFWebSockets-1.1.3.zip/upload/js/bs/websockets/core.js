!function ( $, window, document ) {
  "use strict";

  function buildEchoOptions () {
    let options = {
      namespace: '',
      broadcaster: 'pusher',
      key: XF.config.echo.key,
      forceTLS: false,
      encrypted: true,
      disableStats: true,
      enabledTransports: ['ws', 'wss'],
      csrfToken: XF.config.csrf,
      cluster: XF.config.echo.cluster,
      authEndpoint: XF.config.echo.authEndpoint,
      userAuthentication: {
        endpoint: XF.config.echo.userAuthEndpoint,
        headers: {
          'X-XF-Csrf-Token': XF.config.csrf
        }
      },
      auth: {
        headers: {
          'X-XF-Csrf-Token': XF.config.csrf
        }
      }
    }

    const isSoketi = !options.cluster
    if (isSoketi) {
      options = $.extend(options, {
        wsHost: XF.config.echo.host || window.location.host,
        wsPort: XF.config.echo.port,
        wssPort: XF.config.echo.port
      })
    }

    return options
  }

  XF.Echo = new Echo(buildEchoOptions())

  XF.EchoManager = $.extend(XF.EchoManager || {}, {
    channels: {},

    init () {
      this.echo = XF.Echo

      this.joinDefaultChannels()
      this.addPageUidToAjaxHeaders()
    },

    joinDefaultChannels () {
      this.channels['forum'] = this.echo.channel('Forum')

      if (XF.config.userId) {
        this.channels['visitor'] = this.echo.private('User.' + XF.config.userId)
      }
    },

    addPageUidToAjaxHeaders () {
      $(document).on('ajax:send', ( e, xhr ) => {
        xhr.setRequestHeader('X-WebSockets-Page-Uid', XF.config.echo.pageUid)
      })
    }
  })

  XF.EchoManager.init()
}
(window.jQuery, window, document);